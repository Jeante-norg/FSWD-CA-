// src/components/InventoryForm.jsx
import React from 'react';


function InventoryForm() {

    return (
        <>
            {/* Inventory form */}
        </>
    );
}

export default InventoryForm;
